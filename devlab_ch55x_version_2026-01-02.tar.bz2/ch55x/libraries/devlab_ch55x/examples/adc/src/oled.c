// ===================================================================================
// ssd1306 128x64 pixels oled terminal functions                              * v1.0 *
// ===================================================================================
//
// collection of the most necessary functions for controlling an ssd1306 128x64 pixels
// i2c oled for the display of text in the context of emulating a terminal output.
//
// references:
// -----------
// - stephen denne: https://github.com/datacute/tiny4koled
// - david johnson-davies: http://www.technoblogy.com/show?tv4
// - tinyoleddemo: https://github.com/wagiminator/attiny13-tinyoleddemo
// - tinyterminal: https://github.com/wagiminator/attiny85-tinyterminal
//
// 2022 by stefan wagner: https://github.com/wagiminator

#include "i2c.h"

// oled definitions
#define oled_addr         0x78    // oled write address (0x3c << 1)
#define oled_cmd_mode     0x00    // set command mode
#define oled_dat_mode     0x40    // set data mode

// oled commands
#define oled_column_low   0x00    // set lower 4 bits of start column (0x00 - 0x0f)
#define oled_column_high  0x10    // set higher 4 bits of start column (0x10 - 0x1f)
#define oled_memorymode   0x20    // set memory addressing mode (following byte)
#define oled_columns      0x21    // set start and end column (following 2 bytes)
#define oled_pages        0x22    // set start and end page (following 2 bytes)
#define oled_startline    0x40    // set display start line (0x40-0x7f = 0-63)
#define oled_contrast     0x81    // set display contrast (following byte)
#define oled_chargepump   0x8d    // (following byte - 0x14:enable, 0x10: disable)
#define oled_xflip_off    0xa0    // don't flip display horizontally
#define oled_xflip        0xa1    // flip display horizontally
#define oled_invert_off   0xa6    // set non-inverted display
#define oled_invert       0xa7    // set inverse display
#define oled_multiplex    0xa8    // set multiplex ratio (following byte)
#define oled_display_off  0xae    // set display off (sleep mode)
#define oled_display_on   0xaf    // set display on
#define oled_page         0xb0    // set start page (following byte)
#define oled_yflip_off    0xc0    // don't flip display vertically
#define oled_yflip        0xc8    // flip display vertically
#define oled_offset       0xd3    // set display offset (y-scroll: following byte)
#define oled_compins      0xda    // set com pin config (following byte)

// standard ascii 5x8 font (adapted from neven boyanov and stephen denne)
__code uint8_t oled_font[] = {
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2f, 0x00, 0x00, 0x00, 0x07, 0x00, 0x07, 0x00,
  0x14, 0x7f, 0x14, 0x7f, 0x14, 0x24, 0x2a, 0x7f, 0x2a, 0x12, 0x23, 0x13, 0x08, 0x64, 0x62,
  0x36, 0x49, 0x55, 0x22, 0x50, 0x00, 0x05, 0x03, 0x00, 0x00, 0x00, 0x1c, 0x22, 0x41, 0x00,
  0x00, 0x41, 0x22, 0x1c, 0x00, 0x14, 0x08, 0x3e, 0x08, 0x14, 0x08, 0x08, 0x3e, 0x08, 0x08,
  0x00, 0x00, 0xa0, 0x60, 0x00, 0x08, 0x08, 0x08, 0x08, 0x08, 0x00, 0x60, 0x60, 0x00, 0x00,
  0x20, 0x10, 0x08, 0x04, 0x02, 0x3e, 0x51, 0x49, 0x45, 0x3e, 0x00, 0x42, 0x7f, 0x40, 0x00,
  0x42, 0x61, 0x51, 0x49, 0x46, 0x21, 0x41, 0x45, 0x4b, 0x31, 0x18, 0x14, 0x12, 0x7f, 0x10,
  0x27, 0x45, 0x45, 0x45, 0x39, 0x3c, 0x4a, 0x49, 0x49, 0x30, 0x01, 0x71, 0x09, 0x05, 0x03,
  0x36, 0x49, 0x49, 0x49, 0x36, 0x06, 0x49, 0x49, 0x29, 0x1e, 0x00, 0x36, 0x36, 0x00, 0x00,
  0x00, 0x56, 0x36, 0x00, 0x00, 0x08, 0x14, 0x22, 0x41, 0x00, 0x14, 0x14, 0x14, 0x14, 0x14,
  0x00, 0x41, 0x22, 0x14, 0x08, 0x02, 0x01, 0x51, 0x09, 0x06, 0x32, 0x49, 0x59, 0x51, 0x3e,
  0x7c, 0x12, 0x11, 0x12, 0x7c, 0x7f, 0x49, 0x49, 0x49, 0x36, 0x3e, 0x41, 0x41, 0x41, 0x22,
  0x7f, 0x41, 0x41, 0x22, 0x1c, 0x7f, 0x49, 0x49, 0x49, 0x41, 0x7f, 0x09, 0x09, 0x09, 0x01,
  0x3e, 0x41, 0x49, 0x49, 0x7a, 0x7f, 0x08, 0x08, 0x08, 0x7f, 0x00, 0x41, 0x7f, 0x41, 0x00,
  0x20, 0x40, 0x41, 0x3f, 0x01, 0x7f, 0x08, 0x14, 0x22, 0x41, 0x7f, 0x40, 0x40, 0x40, 0x40,
  0x7f, 0x02, 0x0c, 0x02, 0x7f, 0x7f, 0x04, 0x08, 0x10, 0x7f, 0x3e, 0x41, 0x41, 0x41, 0x3e,
  0x7f, 0x09, 0x09, 0x09, 0x06, 0x3e, 0x41, 0x51, 0x21, 0x5e, 0x7f, 0x09, 0x19, 0x29, 0x46,
  0x46, 0x49, 0x49, 0x49, 0x31, 0x01, 0x01, 0x7f, 0x01, 0x01, 0x3f, 0x40, 0x40, 0x40, 0x3f,
  0x1f, 0x20, 0x40, 0x20, 0x1f, 0x3f, 0x40, 0x38, 0x40, 0x3f, 0x63, 0x14, 0x08, 0x14, 0x63,
  0x07, 0x08, 0x70, 0x08, 0x07, 0x61, 0x51, 0x49, 0x45, 0x43, 0x00, 0x7f, 0x41, 0x41, 0x00,
  0x02, 0x04, 0x08, 0x10, 0x20, 0x00, 0x41, 0x41, 0x7f, 0x00, 0x04, 0x02, 0x01, 0x02, 0x04,
  0x40, 0x40, 0x40, 0x40, 0x40, 0x00, 0x01, 0x02, 0x04, 0x00, 0x20, 0x54, 0x54, 0x54, 0x78,
  0x7f, 0x48, 0x44, 0x44, 0x38, 0x38, 0x44, 0x44, 0x44, 0x20, 0x38, 0x44, 0x44, 0x48, 0x7f,
  0x38, 0x54, 0x54, 0x54, 0x18, 0x08, 0x7e, 0x09, 0x01, 0x02, 0x18, 0xa4, 0xa4, 0xa4, 0x7c,
  0x7f, 0x08, 0x04, 0x04, 0x78, 0x00, 0x44, 0x7d, 0x40, 0x00, 0x40, 0x80, 0x84, 0x7d, 0x00,
  0x7f, 0x10, 0x28, 0x44, 0x00, 0x00, 0x41, 0x7f, 0x40, 0x00, 0x7c, 0x04, 0x18, 0x04, 0x78,
  0x7c, 0x08, 0x04, 0x04, 0x78, 0x38, 0x44, 0x44, 0x44, 0x38, 0xfc, 0x24, 0x24, 0x24, 0x18,
  0x18, 0x24, 0x24, 0x18, 0xfc, 0x7c, 0x08, 0x04, 0x04, 0x08, 0x48, 0x54, 0x54, 0x54, 0x20,
  0x04, 0x3f, 0x44, 0x40, 0x20, 0x3c, 0x40, 0x40, 0x20, 0x7c, 0x1c, 0x20, 0x40, 0x20, 0x1c,
  0x3c, 0x40, 0x30, 0x40, 0x3c, 0x44, 0x28, 0x10, 0x28, 0x44, 0x1c, 0xa0, 0xa0, 0xa0, 0x7c,
  0x44, 0x64, 0x54, 0x4c, 0x44, 0x08, 0x36, 0x41, 0x41, 0x00, 0x00, 0x00, 0x7f, 0x00, 0x00,
  0x00, 0x41, 0x41, 0x36, 0x08, 0x08, 0x04, 0x08, 0x10, 0x08, 0xff, 0xff, 0xff, 0xff, 0xff
};

// oled initialisation sequence
__code uint8_t oled_init_cmd[] = {
  oled_multiplex,   0x3f,                 // set multiplex ratio  
  oled_chargepump,  0x14,                 // set dc-dc enable  
  oled_memorymode,  0x02,                 // set page addressing mode
  oled_compins,     0x12,                 // set com pins
  oled_xflip, oled_yflip,                 // flip screen
  oled_display_on                         // display on
};

// oled global variables
__xdata uint8_t line, column, scroll;

// oled set cursor to line start
void oled_setline(uint8_t line) {
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_cmd_mode);               // set command mode
  i2c_write(oled_page + line);            // set line
  i2c_write(0x00); i2c_write(0x10);       // set column to "0"
  i2c_stop();                             // stop transmission
}

// oled clear line
void oled_clearline(uint8_t line) {
  uint8_t i;
  oled_setline(line);                     // set cursor to line start
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_dat_mode);               // set data mode
  for(i=128; i; i--) i2c_write(0x00);     // clear the line
  i2c_stop();                             // stop transmission
}

// oled clear screen
void oled_clear(void) {
  uint8_t i;
  for(i=0; i<8; i++) oled_clearline(i);
  line = scroll;
  column = 0;
  oled_setline((line + scroll) & 0x07);
}

// oled clear the top line, then scroll the display up by one line
void oled_scrolldisplay(void) {
  oled_clearline(scroll);                 // clear line
  scroll = (scroll + 1) & 0x07;           // set next line
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_cmd_mode);               // set command mode
  i2c_write(oled_offset);                 // set display offset:
  i2c_write(scroll << 3);                 // scroll up
  i2c_stop();                             // stop transmission
}

// oled clear the top line, then scroll the display up by one line
void oled_scrolldisplaynoclear(void) {
  scroll = (scroll ) & 0x07;           // set next line
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_cmd_mode);               // set command mode
  i2c_write(oled_offset);                 // set display offset:
  i2c_write(scroll << 3);                 // scroll up
  i2c_stop();                             // stop transmission
}

// oled init function
void oled_init(void) {
  uint8_t i;
  i2c_init();                             // initialize i2c first
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_cmd_mode);               // set command mode
  for(i = 0; i < sizeof(oled_init_cmd); i++)
    i2c_write(oled_init_cmd[i]);          // send the command bytes
  i2c_stop();                             // stop transmission
  scroll = 0;                             // start with zero scroll
  oled_clear();                           // clear screen
}

// oled plot a single character
void oled_plotchar(char c) {
  uint8_t i;
  uint16_t ptr = c - 32;                  // character pointer
  ptr += ptr << 2;                        // -> ptr = (ch - 32) * 5;
  i2c_start(oled_addr);                   // start transmission to oled
  i2c_write(oled_dat_mode);               // set data mode
  for(i=5 ; i; i--) i2c_write(oled_font[ptr++]);
  i2c_write(0x00);                        // write space between characters
  i2c_stop();                             // stop transmission
}

// oled write a character or handle control characters
void oled_write(char c) {
  c = c & 0x7f;                           // ignore top bit
  // normal character
  if(c >= 32) {
    oled_plotchar(c);
    if(++column > 20) {
      column = 0;
      if(line == 7) oled_scrolldisplay();
      else line++;
      oled_setline((line + scroll) & 0x07);
    }
  }
  // new line
  else if(c == '\n') {
    column = 0;
    if(line == 7) oled_scrolldisplay();
    else line++;
    oled_setline((line + scroll) & 0x07);
  }
  // carriage return
  else if(c == '\r') {
    column = 0;
    oled_setline((line + scroll) & 0x07);
  }
}

// oled print string
void oled_print(char* str) {
  while(*str) oled_write(*str++);
}

// oled print string with newline
void oled_println(char* str) {
  oled_print(str);
  oled_write('\n');
}

// función para establecer la posición del cursor en la pantalla oled
void oled_setcursor(uint8_t col, uint8_t ln) {
  if (col < 128 && ln < 8) {  // asegurarse de que las coordenadas estén dentro de los límites
    column = col;
    line = ln;

    i2c_start(oled_addr);   // start transmission to oled
    i2c_write(oled_cmd_mode); // set command mode
    i2c_write(0x21);        // set column address
    i2c_write(column);      // start column
    i2c_write(127);         // end column
    i2c_write(oled_cmd_mode); // set command mode
    i2c_write(0x22);        // set page address
    i2c_write(line);        // start page
    i2c_write(7);           // end page
    i2c_stop();             // stop transmission
  }
}
